<?php 
 header("Location: ../../../view/"); ?>