<?php 
 header("Location: ../../view/"); ?>