<?php ?>

<title><?php echo $titulo; ?></title>
        <link href="favicon.ico" rel="shortcut icon" type="image/ico" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <link rel="stylesheet" href="http://localhost/otica/public/css/menu.css">
        <link rel="stylesheet" href="http://localhost/otica/public/css/estilo.css">
        <link rel="stylesheet" href="http://localhost/otica/public/css/calendario.css">
        <link rel="stylesheet" href="http://localhost/otica/public/css/tabela.css">
        <script type="text/javascript" src="http://localhost/otica/public/js/util.js"></script> 
        <script type="text/javascript" src="http://localhost/otica/public/js/produto.js"></script> 

        <style type="text/css">

        </style>
    </head>
    <body>
 
