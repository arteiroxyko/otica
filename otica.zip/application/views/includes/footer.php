<?php
$this->session->set_userdata('paginaAnterior',  current_url());
?>


</body>
</html>